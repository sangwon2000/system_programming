/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_336()
{
    return 3347663074U;
}

unsigned getval_493()
{
    return 2462550344U;
}

void setval_225(unsigned *p)
{
    *p = 2421738738U;
}

void setval_259(unsigned *p)
{
    *p = 3267856712U;
}

void setval_206(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_211(unsigned x)
{
    return x + 2438481105U;
}

void setval_280(unsigned *p)
{
    *p = 452576024U;
}

unsigned getval_141()
{
    return 4240674904U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_200(unsigned *p)
{
    *p = 3758704718U;
}

unsigned getval_482()
{
    return 3687110281U;
}

unsigned addval_311(unsigned x)
{
    return x + 2430634440U;
}

unsigned getval_410()
{
    return 3523789197U;
}

void setval_415(unsigned *p)
{
    *p = 3375939979U;
}

unsigned getval_438()
{
    return 3224950281U;
}

void setval_498(unsigned *p)
{
    *p = 3525886345U;
}

unsigned addval_341(unsigned x)
{
    return x + 3767093443U;
}

void setval_144(unsigned *p)
{
    *p = 3397971312U;
}

void setval_487(unsigned *p)
{
    *p = 3385117321U;
}

unsigned addval_188(unsigned x)
{
    return x + 3526934953U;
}

unsigned addval_338(unsigned x)
{
    return x + 3375945353U;
}

unsigned addval_219(unsigned x)
{
    return x + 3286272328U;
}

unsigned getval_270()
{
    return 2425408141U;
}

unsigned getval_242()
{
    return 3674786441U;
}

unsigned addval_430(unsigned x)
{
    return x + 3682915977U;
}

void setval_317(unsigned *p)
{
    *p = 3674262153U;
}

unsigned getval_497()
{
    return 2497743176U;
}

unsigned getval_252()
{
    return 3223374473U;
}

unsigned getval_427()
{
    return 2430642504U;
}

void setval_429(unsigned *p)
{
    *p = 3599583611U;
}

unsigned getval_182()
{
    return 3224947369U;
}

void setval_347(unsigned *p)
{
    *p = 3526934921U;
}

unsigned getval_446()
{
    return 3286272344U;
}

unsigned getval_278()
{
    return 2425411211U;
}

void setval_363(unsigned *p)
{
    *p = 3284240649U;
}

void setval_121(unsigned *p)
{
    *p = 3523794568U;
}

unsigned addval_356(unsigned x)
{
    return x + 3531129225U;
}

void setval_147(unsigned *p)
{
    *p = 3674789512U;
}

unsigned addval_255(unsigned x)
{
    return x + 2430638408U;
}

void setval_160(unsigned *p)
{
    *p = 3531917833U;
}

void setval_484(unsigned *p)
{
    *p = 2428600734U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
